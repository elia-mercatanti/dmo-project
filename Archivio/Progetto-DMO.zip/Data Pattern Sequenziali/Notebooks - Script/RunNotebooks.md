## How to run notebooks:
I suggest to install anaconda (https://anaconda.org/anaconda/python) to have all dependency with one install.


Dependencies:
- Jupyter notebook
- Python 3.6


Python libraries:
- Pandas
- numpy
- matplotlib
- seaborn
